package com.example.demo.Repositories;

public interface IItemRepository {
}
