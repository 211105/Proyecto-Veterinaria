package com.example.demo.Entities;

public class Mob {
}
